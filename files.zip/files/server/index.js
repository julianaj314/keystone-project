// server/index.js  –  Servidor principal
const express    = require('express');
const http       = require('http');
const { Server } = require('socket.io');
const cron       = require('node-cron');
const axios      = require('axios');
const path       = require('path');
const fs         = require('fs');

const app    = express();
const server = http.createServer(app);
const io     = new Server(server);

app.use(express.json());
app.use(express.static(path.join(__dirname, '../public')));

// ─── PERSISTENCIA ─────────────────────────────────────────────────────────────
const DATA_FILE = path.join(__dirname, 'data.json');

function loadData() {
  try {
    return JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
  } catch {
    return {
      esp32Ip: '10.39.223.198',
      schedules: [],
      log: []
    };
  }
}

function saveData(data) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
}

let state = loadData();

// ─── ACTIVACIONES DE CRON ─────────────────────────────────────────────────────
const activeCrons = new Map();  // id → tarea cron

function addLog(message, type = 'info') {
  const entry = { ts: new Date().toISOString(), message, type };
  state.log.unshift(entry);
  if (state.log.length > 100) state.log.pop();
  saveData(state);
  io.emit('log', entry);
}

async function triggerServo(scheduleId) {
  const schedule = state.schedules.find(s => s.id === scheduleId);
  if (!schedule || !schedule.enabled) return;

  addLog(`⏰ Horario "${schedule.name}" activado → moviendo servo a ${schedule.angle}°`, 'info');

  try {
    const url = `http://${state.esp32Ip}/move`;
    const res = await axios.post(url, { angle: schedule.angle }, { timeout: 5000 });
    addLog(`✅ Servo movido a ${res.data.angle}° exitosamente`, 'success');
    io.emit('servo-moved', { angle: res.data.angle, by: schedule.name });
  } catch (err) {
    const msg = err.code === 'ECONNREFUSED'
      ? 'No se pudo conectar al ESP32. Verifica la IP y la red.'
      : err.message;
    addLog(`❌ Error al mover servo: ${msg}`, 'error');
  }
}

function buildCronExpr(schedule) {
  // schedule.time = "HH:MM", schedule.days = [0,1,2,3,4,5,6] (0=Dom)
  const [hour, minute] = schedule.time.split(':');
  const daysStr = schedule.days.length === 7
    ? '*'
    : schedule.days.join(',');
  return `${minute} ${hour} * * ${daysStr}`;
}

function registerCron(schedule) {
  if (activeCrons.has(schedule.id)) {
    activeCrons.get(schedule.id).destroy();
    activeCrons.delete(schedule.id);
  }
  if (!schedule.enabled) return;

  const expr = buildCronExpr(schedule);
  if (!cron.validate(expr)) {
    addLog(`⚠️ Expresión cron inválida para "${schedule.name}": ${expr}`, 'warn');
    return;
  }

  const task = cron.schedule(expr, () => triggerServo(schedule.id), {
    timezone: 'America/Bogota'
  });
  activeCrons.set(schedule.id, task);
  addLog(`📅 Horario "${schedule.name}" registrado (${expr}) – ${schedule.enabled ? 'activo' : 'pausado'}`, 'info');
}

// Cargar horarios existentes al iniciar
state.schedules.forEach(registerCron);

// ─── API REST ──────────────────────────────────────────────────────────────────

// Configuración ESP32
app.get('/api/config', (_, res) => {
  res.json({ esp32Ip: state.esp32Ip });
});

app.post('/api/config', (req, res) => {
  const { esp32Ip } = req.body;
  if (!esp32Ip) return res.status(400).json({ error: 'IP requerida' });
  state.esp32Ip = esp32Ip;
  saveData(state);
  addLog(`🔧 IP del ESP32 actualizada a ${esp32Ip}`, 'info');
  res.json({ ok: true, esp32Ip });
});

// Probar conexión con ESP32
app.get('/api/ping', async (_, res) => {
  try {
    const r = await axios.get(`http://${state.esp32Ip}/status`, { timeout: 4000 });
    addLog(`🟢 ESP32 respondió: IP=${r.data.ip}, RSSI=${r.data.rssi} dBm`, 'success');
    res.json({ ok: true, data: r.data });
  } catch (e) {
    addLog(`🔴 Sin respuesta del ESP32 en ${state.esp32Ip}`, 'error');
    res.status(503).json({ ok: false, error: e.message });
  }
});

// Mover servo manualmente
app.post('/api/move', async (req, res) => {
  const { angle } = req.body;
  if (angle === undefined || angle < 0 || angle > 180)
    return res.status(400).json({ error: 'Ángulo inválido (0-180)' });
  try {
    const r = await axios.post(`http://${state.esp32Ip}/move`, { angle }, { timeout: 5000 });
    addLog(`🎮 Movimiento manual: ${r.data.angle}°`, 'info');
    io.emit('servo-moved', { angle: r.data.angle, by: 'Manual' });
    res.json({ ok: true, angle: r.data.angle });
  } catch (e) {
    res.status(503).json({ ok: false, error: e.message });
  }
});

// CRUD Horarios
app.get('/api/schedules', (_, res) => {
  res.json(state.schedules);
});

app.post('/api/schedules', (req, res) => {
  const { name, time, days, angle, enabled } = req.body;
  if (!name || !time || !days || angle === undefined)
    return res.status(400).json({ error: 'Faltan campos' });

  const schedule = {
    id: Date.now().toString(),
    name, time,
    days: Array.isArray(days) ? days : [days],
    angle: Math.min(180, Math.max(0, Number(angle))),
    enabled: enabled !== false
  };
  state.schedules.push(schedule);
  saveData(state);
  registerCron(schedule);
  res.json(schedule);
});

app.put('/api/schedules/:id', (req, res) => {
  const idx = state.schedules.findIndex(s => s.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: 'No encontrado' });

  const updated = { ...state.schedules[idx], ...req.body, id: req.params.id };
  state.schedules[idx] = updated;
  saveData(state);
  registerCron(updated);
  res.json(updated);
});

app.delete('/api/schedules/:id', (req, res) => {
  const idx = state.schedules.findIndex(s => s.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: 'No encontrado' });

  if (activeCrons.has(req.params.id)) {
    activeCrons.get(req.params.id).destroy();
    activeCrons.delete(req.params.id);
  }
  const [removed] = state.schedules.splice(idx, 1);
  saveData(state);
  addLog(`🗑️ Horario "${removed.name}" eliminado`, 'info');
  res.json({ ok: true });
});

// Log
app.get('/api/log', (_, res) => {
  res.json(state.log);
});

// ─── SOCKET.IO ────────────────────────────────────────────────────────────────
io.on('connection', socket => {
  socket.emit('init', {
    esp32Ip:   state.esp32Ip,
    schedules: state.schedules,
    log:       state.log.slice(0, 30)
  });
});

// ─── START ────────────────────────────────────────────────────────────────────
const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`\n🚀 Servidor corriendo en http://localhost:${PORT}`);
  console.log(`📡 Conectando con ESP32 en ${state.esp32Ip}`);
});
