# ESP32 Servo Scheduler 🎛️

Controla un servomotor en un ESP32 por WiFi desde una interfaz web. Programa horarios con días y horas personalizadas.

---

## 🗂️ Estructura del proyecto

```
esp32-servo-scheduler/
├── esp32-firmware/
│   └── esp32_servo_controller.ino   ← Código para el ESP32
├── server/
│   └── index.js                     ← Servidor Node.js
├── public/
│   └── index.html                   ← Interfaz web
└── package.json
```

---

## ⚡ Parte 1: Programar el ESP32

### Librerías requeridas (Arduino IDE → Gestor de librerías)
- **ESP32Servo** — por Kevin Harrington
- **ArduinoJson** — por Benoit Blanchon

### Pasos
1. Abre `esp32-firmware/esp32_servo_controller.ino` en Arduino IDE
2. Edita las líneas:
   ```cpp
   const char* WIFI_SSID     = "TU_RED_WIFI";
   const char* WIFI_PASSWORD = "TU_CONTRASEÑA";
   ```
3. Selecciona la placa: **ESP32 Dev Module**
4. Carga el sketch al ESP32
5. Abre el Monitor Serie (115200 baud) → verás la IP asignada, por ejemplo: `192.168.1.105`

### Conexión del servo
```
Servo (cable naranja/amarillo) → GPIO 18
Servo (cable rojo)             → 5V  (o 3.3V según tu servo)
Servo (cable marrón/negro)     → GND
```

---

## 🚀 Parte 2: Correr la aplicación Node.js

```bash
# Instalar dependencias
npm install

# Iniciar el servidor
npm start
```

Abre tu navegador en: **http://localhost:3000**

---

## 🖥️ Uso de la interfaz

1. **Conexión ESP32**: Ingresa la IP del ESP32 y pulsa "Probar conexión"
2. **Control Manual**: Mueve el slider o usa los botones de presets para girar el servo
3. **Horarios**: Crea un horario con nombre, hora, días de la semana y ángulo destino
4. **Log**: Monitorea en tiempo real todos los eventos y movimientos

---

## 📡 API del servidor (para integraciones externas)

| Método | Ruta | Descripción |
|--------|------|-------------|
| GET | `/api/config` | Obtener IP del ESP32 configurada |
| POST | `/api/config` | Cambiar IP: `{"esp32Ip":"192.168.1.x"}` |
| GET | `/api/ping` | Probar conexión con ESP32 |
| POST | `/api/move` | Mover servo: `{"angle":90}` |
| GET | `/api/schedules` | Listar horarios |
| POST | `/api/schedules` | Crear horario |
| PUT | `/api/schedules/:id` | Editar horario |
| DELETE | `/api/schedules/:id` | Eliminar horario |
| GET | `/api/log` | Ver log de actividad |

---

## 🔧 Requisitos

- Node.js v16+
- Arduino IDE 2.x con soporte ESP32
- ESP32 y un servomotor (SG90, MG996R, etc.)
- ESP32 y la PC en la **misma red WiFi**
