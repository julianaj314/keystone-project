/*
 * ESP32 Servo Controller - Controlado por WiFi
 * 
 * Librerías necesarias (instalar en Arduino IDE):
 *   - ESP32Servo (por Kevin Harrington)
 *   - ArduinoJson (por Benoit Blanchon)
 * 
 * Placa: ESP32 Dev Module
 * 
 * Conexión del servo:
 *   - Señal (naranja/amarillo) → GPIO 18
 *   - VCC (rojo)              → 5V o 3.3V (según tu servo)
 *   - GND (marrón/negro)      → GND
 */

#include <WiFi.h>
#include <WebServer.h>
#include <ESP32Servo.h>
#include <ArduinoJson.h>

// ─── CONFIGURACIÓN ────────────────────────────────────────────────────────────
const char* WIFI_SSID     = "Prueba";       // <── Cambia esto
const char* WIFI_PASSWORD = "Bmo12345";      // <── Cambia esto
const int   SERVO_PIN     = 18;
const int   SERVER_PORT   = 80;
// ──────────────────────────────────────────────────────────────────────────────

WebServer server(SERVER_PORT);
Servo servo;

int  currentAngle   = 0;
bool servoAttached  = false;

// Desconecta el servo después de moverse (evita zumbido)
void detachAfterMove() {
  delay(800);
  servo.detach();
  servoAttached = false;
}

void moveServo(int angle) {
  angle = constrain(angle, 0, 180);
  if (!servoAttached) {
    servo.attach(SERVO_PIN);
    servoAttached = true;
  }
  servo.write(angle);
  currentAngle = angle;
  Serial.printf("[SERVO] Movido a %d°\n", angle);
  detachAfterMove();
}

// ─── CORS helper ──────────────────────────────────────────────────────────────
void setCORSHeaders() {
  server.sendHeader("Access-Control-Allow-Origin", "*");
  server.sendHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
  server.sendHeader("Access-Control-Allow-Headers", "Content-Type");
}

// ─── RUTAS HTTP ───────────────────────────────────────────────────────────────

// GET /status  → devuelve ángulo actual y uptime
void handleStatus() {
  setCORSHeaders();
  StaticJsonDocument<128> doc;
  doc["angle"]   = currentAngle;
  doc["uptime"]  = millis() / 1000;
  doc["ip"]      = WiFi.localIP().toString();
  doc["rssi"]    = WiFi.RSSI();
  String body;
  serializeJson(doc, body);
  server.send(200, "application/json", body);
}

// POST /move   → body: {"angle": 90}
void handleMove() {
  setCORSHeaders();
  if (!server.hasArg("plain")) {
    server.send(400, "application/json", "{\"error\":\"Body vacío\"}");
    return;
  }
  StaticJsonDocument<64> doc;
  DeserializationError err = deserializeJson(doc, server.arg("plain"));
  if (err) {
    server.send(400, "application/json", "{\"error\":\"JSON inválido\"}");
    return;
  }
  int angle = doc["angle"] | -1;
  if (angle < 0 || angle > 180) {
    server.send(400, "application/json", "{\"error\":\"Ángulo debe ser 0-180\"}");
    return;
  }
  moveServo(angle);
  StaticJsonDocument<64> res;
  res["ok"]    = true;
  res["angle"] = currentAngle;
  String body;
  serializeJson(res, body);
  server.send(200, "application/json", body);
}

// OPTIONS (preflight CORS)
void handleOptions() {
  setCORSHeaders();
  server.send(204);
}

// ─── SETUP ────────────────────────────────────────────────────────────────────
void setup() {
  Serial.begin(115200);
  Serial.println("\n[ESP32] Iniciando...");

  // Conectar WiFi
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  Serial.print("[WiFi] Conectando");
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.printf("\n[WiFi] Conectado! IP: %s\n", WiFi.localIP().toString().c_str());

  // Registrar rutas
  server.on("/status",  HTTP_GET,     handleStatus);
  server.on("/move",    HTTP_POST,    handleMove);
  server.on("/move",    HTTP_OPTIONS, handleOptions);
  server.on("/status",  HTTP_OPTIONS, handleOptions);

  server.begin();
  Serial.printf("[HTTP] Servidor escuchando en puerto %d\n", SERVER_PORT);
  Serial.println("[ESP32] Listo para recibir comandos.");
}

// ─── LOOP ─────────────────────────────────────────────────────────────────────
void loop() {
  server.handleClient();
}
